



import logging
import os
import ssl
import boto3
import urllib
import xml.etree.ElementTree as et

from botocore.exceptions import ClientError







secfw = {}
prifw = {}

event = {}
context = {}
gcontext = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)

ec2 = boto3.resource('ec2')


ec2_c = boto3.client('ec2')
client = boto3.client('ec2')
events_client = boto3.client('events')
logger = logging.getLogger()
logger.setLevel(logging.INFO)






def replace_vpc_route_to_fw(route_table_id, destination_cidr_block, NetworkInterfaceId, DryRun=False):
    ec2 = boto3.client('ec2')

    try:
        ec2.delete_route(
        DestinationCidrBlock=destination_cidr_block,
        RouteTableId=route_table_id
        )
    except ClientError as e:
        logger.info("Got error {0} deleting route Moving on.".format(e))
        return None

    try:
        resp = ec2.create_route(
            DryRun=False,
            DestinationCidrBlock=destination_cidr_block,
            RouteTableId=route_table_id,
            NetworkInterfaceId=NetworkInterfaceId
        )
    except ClientError as e:
        logger.info("Got error {0} adding route Moving on.".format(e))
        return None
    return resp



def failover(route_table_id, failed_eni, backup_eni):
    ec2_client = boto3.client('ec2')
    route_table = ec2_client.describe_route_tables(RouteTableIds=[route_table_id])
    Interfaceids = []
    routes = route_table['RouteTables'][0]['Routes']
    for route in routes:
        key = 'NetworkInterfaceId'
        if key in route:
            eni1 = route['NetworkInterfaceId']
            if route['NetworkInterfaceId'] == failed_eni:
                destination_cidr_block = route['DestinationCidrBlock']
                replace_vpc_route_to_fw(route_table_id, destination_cidr_block, backup_eni, DryRun=False)




def get_firewall_status(gwMgmtIp, api_key):

        global gcontext

        cmd = urllib.request.Request(
            "https://" + gwMgmtIp + "/api/?type=op&cmd=<show><chassis-ready></chassis-ready></show>&key=" + api_key)
        # Send command to fw and see if it times out or we get a response
        logger.info('[INFO]: Sending command: %s', cmd)
        try:
            response = urllib.request.urlopen(cmd, data=None, context=gcontext, timeout=5).read()
            # Now we do stuff to the gw
        except urllib.error.URLError:
            logger.info("[INFO]: No response from FW. So maybe not up!")
            return 'down'
            # sleep and check again?
        else:
            logger.info("[INFO]: FW is responding!!")

        logger.info("[RESPONSE]: {}".format(response))
        resp_header = et.fromstring(response)

        if resp_header.tag != 'response':
            logger.info("[ERROR]: didn't get a valid response from firewall...maybe a timeout")
            return 'down'

        if resp_header.attrib['status'] == 'error':
            logger.info("[ERROR]: Got an error for the command")
            return 'down'

        if resp_header.attrib['status'] == 'success':
            # The fw responded with a successful command execution
            for element in resp_header:
                if element.text.rstrip() == 'yes':
                    # Call config gw command?
                    logger.info("[INFO]: FW is ready for configure")
                    return 'running'
        else:
            return 'down'





def lambda_handler(event, context):

    preempt = os.environ['preempt']
    vpc_summary_route = os.environ['VpcSummaryRoute']
    fw1_trust_eni = os.environ['fw1Trusteni']
    fw2_trust_eni = os.environ['fw2Trusteni']
    route_table_id = os.environ['fromTGWRouteTableId']
    fw1_trust_ip = os.environ['fw1Trustip']
    fw2_trust_ip = os.environ['fw2Trustip']
    api_key = os.environ['apikey']
    split_routes = os.environ['splitroutes']


    def_route = '0.0.0.0/0'

    # fw1_trust_eni = 'eni-09539d453383a172a'
    # fw2_trust_eni = 'eni-04fe20fe0f4f3f374'

    global gcontext

    prifwstatus = get_firewall_status(gwMgmtIp = fw1_trust_ip, api_key = api_key)
    secfwstatus = get_firewall_status(gwMgmtIp = fw2_trust_ip, api_key = api_key)

    if (split_routes) == 'yes':
        def_route_nic = fw1_trust_eni
        vpc_summary_nic = fw2_trust_eni
    else:
        def_route_nic = fw1_trust_eni
        vpc_summary_nic = fw1_trust_eni


    if ((prifwstatus == 'running') and (secfwstatus == 'running')):
        if preempt == 'no':
            logger.info("Both firewalls running - exiting and we cannot failback")
            exit()
        else:
            replace_vpc_route_to_fw(route_table_id, vpc_summary_route, vpc_summary_nic, DryRun=False)
            replace_vpc_route_to_fw(route_table_id, def_route, def_route_nic, DryRun=False)

    elif ((prifwstatus != 'running') and (secfwstatus == 'running')):
        try:
            failover(route_table_id, fw1_trust_eni, fw2_trust_eni)
        except Exception as e:
            logger.info("Disassociation Fail [RESPONSE]: {}".format(e))

    elif ((prifwstatus == 'running') and (secfwstatus != 'running')):
        try:
            failover(route_table_id, fw2_trust_eni, fw1_trust_eni)
        except Exception as e:
            logger.info("Disassociation Fail [RESPONSE]: {}".format(e))

